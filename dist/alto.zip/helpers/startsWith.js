module.exports = function startsWith(str, prefix) {
	return str && str.startsWith(prefix);
};
