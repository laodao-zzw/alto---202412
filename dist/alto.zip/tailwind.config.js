/*
 * @Author: Ziwei Zhu
 * @Date: 2024-12-15 16:42:42
 * @Last Modified by: Ziwei Zhu
 * @Last Modified time: Do not edit
 */
module.exports = {
  content: ['./**/*.hbs'],
  theme: {
    extend: {},
  },
  plugins: [],
}